
from enum import Enum
import copy
import os
import csv

from tax import amount_of_deferred_asset_to_sell, amount_of_regular_asset_to_sell,\
    _calculate_tax, calculate_marginal_tax, get_oas_clawback, get_taxable_income

dir = os.path.dirname(__file__)
fn = os.path.join(dir, 'LIF_withdrawal_rates.csv')

lif_withdrawal = {}

#AGE,MINIMUM,MAXIMUM_ONTARIO,MAXIMUM_QUEBEC,MAXIMUM_FED
with open(fn, mode='r') as csv_file:
    csv_reader = csv.reader(csv_file)
    header = True
    for row in csv_reader:
        if header:
            header = False
            continue

        lif_withdrawal[int(row[0])] = {"minimum": float(row[1]), "maximum_ontario": float(row[2])}




def get_min_withdrawal_rate(age):
    return lif_withdrawal[age]["minimum"]

def get_max_withdrawal_rate(age):
    return lif_withdrawal[age]["maximum_ontario"]





from transaction_types import TransactionType



class Account(str, Enum):
    REGULAR="NON_REGISTERED_ASSET",
    REGULAR_BOOK_VALUE = "REGULAR_BOOK_VALUE"
    RRSP="RRSP",
    RRIF="RRIF",
    TFSA = "TFSA",
    LIRA="LIRA",
    LIF="LIF",
    HOME = "HOME",
    CLEARING = "CLEARING"


class Transaction():
    def __init__(self, entry_type, person, account, amount, transaction_type, book_value=0, desc=""):
        self.entry_type = entry_type
        self.person = person
        self.account = account
        self.amount = amount
        self.transaction_type = transaction_type
        self.book_value = book_value
        self.desc = desc



def get_future_value(start_year, future_year, value, factor):
    return round(value * (1 + factor) ** (future_year - start_year),0)


def createTransaction(transactions, entry_type, person, account, amount, transaction_type, book_value=0, desc=""):
    transaction = Transaction(entry_type, person, account, amount, transaction_type, book_value=book_value, desc=desc)

    transactions.append(transaction)

    return transaction


def get_capital(book):

    total = book['joint'][Account.CLEARING]

    total += book['joint'][Account.HOME]

    total += book['client'][Account.REGULAR]
    total += book['client'][Account.RRIF]
    total += book['client'][Account.RRSP]
    total += book['client'][Account.TFSA]
    total += book['client'][Account.LIRA]
    total += book['client'][Account.LIF]

    if 'spouse' not in book.keys():
        return total

    total += book['spouse'][Account.REGULAR]
    total += book['spouse'][Account.RRIF]
    total += book['spouse'][Account.RRSP]
    total += book['spouse'][Account.TFSA]
    total += book['spouse'][Account.LIRA]
    total += book['spouse'][Account.LIF]

    return total



def process_transactions(book, transactions):
    book = copy.deepcopy(book)

    for transaction in transactions:
        person = transaction.person
        account = transaction.account
        amount = transaction.amount
        type = transaction.entry_type

        if account==Account.CLEARING:
            person = "joint"


        if type == "debit":
            book[person][account] -= amount
        else:
            book[person][account] += amount

    return book


def transfer_assets_after_spouse_death(transactions, book, xfer_from, xfer_to):
    accounts = [Account.REGULAR, Account.LIRA, Account.LIF, Account.TFSA, Account.RRSP,  Account.RRIF]

    for account in accounts:
        createTransaction(transactions, "debit", xfer_from, account, book[xfer_from][account], TransactionType.TRANSFER_ASSETS_TO_SPOUSE, desc="transfer to spouse")
        createTransaction(transactions, "credit", xfer_to, account, book[xfer_from][account], TransactionType.TRANSFER_ASSETS_TO_SPOUSE, desc="transfer to spouse")







def get_age(start_age, start_year, current_year):
    age = start_age + current_year - start_year
    return age





def rrsp_converstion_to_rrif(transactions, book, person):

    createTransaction(transactions, "debit", person, Account.RRSP, book[person][Account.RRSP], TransactionType.RRSP_CONVERSION, desc="rrsp conversion")
    createTransaction(transactions, "credit", person, Account.RRIF, book[person][Account.RRSP], TransactionType.RRSP_CONVERSION, desc="rrsp conversion")



def convert_lira_to_lif(transactions, book, person):

    createTransaction(transactions, "debit", person, Account.LIRA, book[person][Account.LIRA], TransactionType.LIRA_CONVERSION, desc="lira conversion")
    createTransaction(transactions, "credit", person, Account.LIF, book[person][Account.LIRA], TransactionType.LIRA_CONVERSION, desc="lira conversion")






def get_mandatory_rrif_withdrawals(transactions, book, age, person):

    if book[person][Account.RRIF] > 0 and age >= 65:
        if age == 90:
            amount = book[person][Account.RRIF]
        else:
            amount = round(book[person][Account.RRIF] / (90 - age), 0)
        createTransaction(transactions, "debit", person, Account.RRIF, amount, TransactionType.RRIF_WITHDRAWAL, desc="mandatory rrif withdrawal")
        createTransaction(transactions, "credit",person, Account.CLEARING, amount, TransactionType.RRIF_WITHDRAWAL, desc="mandatory rrif withdrawal")


def get_mandatory_lif_withdrawals(transactions, book, age, person):

    if book[person][Account.LIF] > 0 and age >= 50:

        rate = get_min_withdrawal_rate(age)
        amount = book[person][Account.RRIF] * rate  #fix this

        createTransaction(transactions, "debit", person, Account.RRIF, amount, TransactionType.LIF_WITHDRAWAL, desc="mandatory lif withdrawal")
        createTransaction(transactions, "credit",person, Account.CLEARING, amount, TransactionType.LIF_WITHDRAWAL, desc="mandatory lif withdrawal")


def sell_regular_asset(transactions, person, book, amount, tax_rate):
    income = get_taxable_income(transactions, person)
    total = book[person][Account.REGULAR]
    bookvalue =book[person][Account.REGULAR_BOOK_VALUE]
    createTransaction(transactions,"debit", person, Account.REGULAR, amount, TransactionType.SALE_OF_REGULAR_ASSET, book_value=round((amount / total) * bookvalue, 0), desc="sell asset")
    createTransaction(transactions,"debit", person, Account.REGULAR_BOOK_VALUE, round((amount / total) * bookvalue,0), TransactionType.BOOK_VALUE_ADJUSTMENT)
    createTransaction(transactions,"credit", person, Account.CLEARING, amount, TransactionType.SALE_OF_REGULAR_ASSET)

    realized_cap_gain = (amount * (total - bookvalue) / total) * 0.5
    tax = calculate_marginal_tax(income, realized_cap_gain, tax_rate)
    createTransaction(transactions,"debit", person, Account.CLEARING, tax, TransactionType.TAX, desc="tax on sale of asset")



def sell_deferred(transactions, person,  account, amount, tax_rate):
    income = get_taxable_income(transactions, person)
    if account == Account.RRSP:
        transaction=TransactionType.RRSP_WITHDRAWAL
        desc="tax on sale of rrsp"
    elif account == Account.RRIF:
        transaction = TransactionType.RRIF_WITHDRAWAL
        desc="tax on sale of rrif"
    elif account == Account.LIF:
        transaction = TransactionType.LIF_WITHDRAWAL
        desc="tax on sale of lif"
    else:
        return

    createTransaction(transactions, "debit", person, account, amount, transaction)
    createTransaction(transactions, "credit", person, Account.CLEARING, amount, transaction)
    tax = calculate_marginal_tax(income, amount, tax_rate)
    createTransaction(transactions, "debit", person, Account.CLEARING, tax, TransactionType.TAX, desc=desc)



def sell_tfsa(transactions, person, amount):
    createTransaction(transactions, "debit", person, Account.TFSA, amount, TransactionType.TFSA_WITHDRAWAL)
    createTransaction(transactions, "credit", person, Account.CLEARING, amount, TransactionType.TFSA_WITHDRAWAL)


def process_pensions(transactions, start_year, year, pensions):
    for pension in pensions:
        if pension["start_year"] <= year and pension["end_year"] >= year:

            pension_amount= get_future_value(start_year, year, pension["amount"], pension["index_rate"])
            createTransaction(transactions, "credit", pension["person"], Account.CLEARING, pension_amount, TransactionType.PENSION_INCOME, desc=pension["name"])


def process_income_requirements(transactions, start_year, year, income_requirements):
    for income_requirement in income_requirements:
        if income_requirement["start_year"] <= year and income_requirement["end_year"] >= year:
            need = get_future_value(start_year, year, income_requirement["amount"], income_requirement["index_rate"])
            createTransaction(transactions, "debit", "joint", Account.CLEARING, need, TransactionType(income_requirement["type"]))


def process_interest_expense(transactions, current_book, interest_rate):

    if current_book['joint'][Account.CLEARING] < 0:
        createTransaction(transactions, "debit", "joint", Account.CLEARING, current_book['joint'][Account.CLEARING] * (-1) * interest_rate, TransactionType.OVERDRAFT_INTEREST)



def process_charitable_donations(transactions, joint_plan, start_year, year, donations):

    donation_amount = 0
    for donation in donations:
        if donation["start_year"] <= year and donation["end_year"] >= year:
            donation_amount= get_future_value(start_year, year, donation["amount"], donation["index_rate"])

    if donation_amount == 0:
        return

    if not joint_plan:
        createTransaction(transactions, "debit", "client", Account.CLEARING, donation_amount, TransactionType.CHARITABLE_DONATIONS, desc="charitable donation")
        return

    #need to allocate dontation between client and spouse

    client_income = get_taxable_income(transactions, "client")
    spouse_income = get_taxable_income(transactions, "spouse")

    if client_income > spouse_income:
        higher_income, lower_income = "client", "spouse"
    else:
        higher_income, lower_income = "spouse", "client"

    income_difference = abs(client_income - spouse_income)

    if income_difference >= donation_amount:
        createTransaction(transactions, "debit", higher_income, Account.CLEARING, donation_amount,
                          TransactionType.CHARITABLE_DONATIONS, desc="charitable donation")

    else:
        higher_allocation = income_difference + (donation_amount - income_difference) / 2
        lower_allocation = higher_allocation - income_difference
        createTransaction(transactions, "debit", higher_income, Account.CLEARING, higher_allocation,
                              TransactionType.CHARITABLE_DONATIONS, desc="charitable donation")
        createTransaction(transactions, "debit", lower_income, Account.CLEARING, lower_allocation,
                          TransactionType.CHARITABLE_DONATIONS, desc="charitable donation")




def process_oas_clawback(transactions, spouse):

    oas_clawback = get_oas_clawback(transactions, "client")
    if oas_clawback > 0:
        createTransaction(transactions, "debit", "client", Account.CLEARING, oas_clawback, TransactionType.OAS_CLAWBACK)

    if not spouse:
        return

    oas_clawback = get_oas_clawback(transactions, "spouse")
    if oas_clawback > 0:
        createTransaction(transactions, "debit", "spouse", Account.CLEARING, oas_clawback, TransactionType.OAS_CLAWBACK)


def process_incomes(transactions, start_year, year, incomes):
    for income in incomes:
        if income["start_year"] <= year and income["end_year"] >= year:

            pension_amount= get_future_value(start_year, year, income["amount"], income["index_rate"])
            createTransaction(transactions, "credit", income["person"], Account.CLEARING, pension_amount, TransactionType.EARNED_INCOME)


def calculate_tax(transactions, person, tax_rates):
    taxable_income=get_taxable_income(transactions, person)
    tax = _calculate_tax(taxable_income, tax_rates)
    return tax




def generate_base_transactions(transactions, current_book, parameters, tax_rate):


    year = current_book["year"]

    if parameters["spouse"]:
        if get_age(year, parameters['start_year'], parameters['client_age']) == (parameters["client_life_expectancy"] + 1):
            transfer_assets_after_spouse_death(transactions, current_book, "client", "spouse")
        elif get_age(year, parameters['start_year'], parameters['spouse_age']) == (parameters["spouse_life_expectancy"] + 1):
            transfer_assets_after_spouse_death(transactions, current_book, "spouse", "client")



    process_income_requirements(transactions, parameters["start_year"], year, parameters["income_requirements"])

    process_interest_expense(transactions, current_book, parameters["interest_rate"])



    process_pensions(transactions, parameters["start_year"], year, parameters["pensions"])
    process_incomes(transactions, parameters["start_year"], year, parameters["incomes"])

    if get_age(year, parameters['start_year'], parameters['client_age']) == 71:
        rrsp_converstion_to_rrif(transactions, current_book,'client' )
        convert_lira_to_lif(transactions, current_book, "client")

    if parameters["spouse"] and get_age(year, parameters['start_year'], parameters['spouse_age']) == 71:
        rrsp_converstion_to_rrif(transactions, current_book, 'spouse')
        convert_lira_to_lif(transactions, current_book, 'spouse')

    if "sell_home" in parameters.keys() and parameters["sell_home"] == year:
        createTransaction(transactions, "credit", "joint", Account.CLEARING, current_book["joint"][Account.HOME], TransactionType.SALE_OF_HOME)
        createTransaction(transactions, "debit", "joint", Account.HOME, current_book["joint"][Account.HOME], TransactionType.SALE_OF_HOME)


    for pli in parameters["pli"]:
        if pli["person"] == "client":
          if get_age(year, parameters['start_year'], parameters['client_age']) == parameters["client_life_expectancy"]:
              createTransaction(transactions, "credit", "joint", Account.CLEARING, pli["amount"],
                                TransactionType.PERMANENT_LIFE_INSURANCE)
        else:
            if get_age(year, parameters['start_year'], parameters['spouse_age']) == parameters[
                "spouse_life_expectancy"]:
                createTransaction(transactions, "credit", "joint", Account.CLEARING, pli["amount"],
                                  TransactionType.PERMANENT_LIFE_INSURANCE)





    current_book = process_transactions(current_book, transactions)

    if current_book["joint"][Account.HOME] > 0:
        createTransaction(transactions, "credit", "joint", Account.HOME, round(current_book["joint"][Account.HOME] * parameters["inflation"], 0), TransactionType.HOME_APPRECIATION)

    get_mandatory_rrif_withdrawals(transactions, current_book, get_age(year, parameters['start_year'], parameters['client_age']), 'client')

    if parameters["spouse"]:
        get_mandatory_rrif_withdrawals(transactions, current_book, get_age(year, parameters['start_year'], parameters['spouse_age']), 'spouse')


    for person in ["client", "spouse"]:

        if (current_book[person][Account.REGULAR] > 0 and parameters["growth_rate"] > 0):
            createTransaction(transactions,"credit", person, Account.REGULAR, round(current_book[person][Account.REGULAR] * parameters["growth_rate"],0), TransactionType.REGULAR_ASSET_GROWTH)
        if (current_book[person][Account.REGULAR] > 0 and parameters["income_rate"] > 0):
            createTransaction(transactions,"credit", person, Account.CLEARING, round(current_book[person][Account.REGULAR] * parameters["income_rate"],0), TransactionType.REGULAR_DIVIDEND)

        for account in [Account.RRSP, Account.RRIF, Account.TFSA, Account.LIRA, Account.LIF]:
            if (current_book[person][account] > 0 and parameters["growth_rate"] > 0):
                createTransaction(transactions, "credit", person, account,
                                  round(current_book[person][account] * parameters["growth_rate"], 0),
                                  TransactionType.REGISTERED_ASSET_GROWTH)
            if (current_book[person][account] > 0 and parameters["income_rate"] > 0):
                createTransaction(transactions, "credit", person, account,
                                  round(current_book[person][account] * parameters["income_rate"], 0),
                                  TransactionType.REGISTERERD_DIVIDEND)

    process_charitable_donations(transactions, parameters["spouse"], parameters["start_year"], year, parameters["charitable_donations"])
    process_oas_clawback(transactions, parameters["spouse"])

    client_tax = calculate_tax(transactions,  "client", tax_rate)
    createTransaction(transactions, "debit", "client", Account.CLEARING, client_tax, TransactionType.TAX, desc="client tax before sale of assets")
    spouse_tax = calculate_tax(transactions, "spouse", tax_rate)
    createTransaction(transactions, "debit", "spouse", Account.CLEARING, spouse_tax, TransactionType.TAX, desc="spouse tax before sale of assets")

def meet_cash_req_from_regular_asset(transactions, book, person, tax_rate, needs, income_limit=0):

    taxable_income = get_taxable_income(transactions, person)
    #needs = 0 - book['joint'][Account.CLEARING]
    if book[person][Account.REGULAR] <= 0:
        return
    book_value_ratio = (book[person][Account.REGULAR] - book[person][Account.REGULAR_BOOK_VALUE]) / book[person][Account.REGULAR]

    regular_asset_needed = amount_of_regular_asset_to_sell(transactions, person, needs, book_value_ratio, taxable_income, tax_rate)

    if income_limit > 0:
        if taxable_income >= income_limit:
            return #do nothing
        if regular_asset_needed * book_value_ratio + taxable_income > income_limit:
            regular_asset_needed = (income_limit - taxable_income) / book_value_ratio


    if regular_asset_needed <= book[person][Account.REGULAR]:
        sell_regular_asset(transactions, person, book, regular_asset_needed, tax_rate)
    else:
        sell_regular_asset(transactions, person, book, book[person][Account.REGULAR], tax_rate)

    process_oas_clawback(transactions, person)



def meet_cash_req_from_deferred(transactions, book, person, account, tax_rate, needs, income_limit=0):
    taxable_income = get_taxable_income(transactions, person)
    #needs = 0 - book['joint'][Account.CLEARING]

    if book[person][account] <= 0:
        return

    deferred_asset_needed = amount_of_deferred_asset_to_sell(transactions, person, needs, taxable_income, tax_rate)

    if income_limit > 0:
        if taxable_income > income_limit:
            return
        if deferred_asset_needed + taxable_income > income_limit:
            deferred_asset_needed = income_limit - taxable_income


    if deferred_asset_needed <= book[person][account]:
        sell_deferred(transactions, person, account, deferred_asset_needed, tax_rate)
    else:
        sell_deferred(transactions, person, account,  book[person][account], tax_rate)

    process_oas_clawback(transactions, person)

def meet_cash_req_from_lif(transactions, book, person, age, tax_rate, needs, income_limit):
    taxable_income = get_taxable_income(transactions, person)
    #needs = 0 - book['joint'][Account.CLEARING]

    if book[person][Account.LIF] <= 0:
        return

    rate = get_max_withdrawal_rate(age)
    max_lif_withdrawal = book[person][Account.LIF] * rate

    deferred_asset_needed = amount_of_deferred_asset_to_sell(needs, taxable_income, tax_rate)

    if income_limit > 0:
        if taxable_income > income_limit:
            return
        if deferred_asset_needed + taxable_income > income_limit:
            deferred_asset_needed = income_limit - taxable_income

    if deferred_asset_needed <= max_lif_withdrawal:
        sell_deferred(transactions, person, Account.LIF, deferred_asset_needed, tax_rate)
    else:
        sell_deferred(transactions, person, Account.LIF,  max_lif_withdrawal, tax_rate)

    process_oas_clawback(transactions, person)


def meet_cash_req_from_tfsa(transactions, book, person, needs, income_limit):

    taxable_income = get_taxable_income(transactions, person)

    if book[person][Account.TFSA] <= 0:
        return

    if income_limit > 0 and taxable_income >= income_limit:
        return


    if needs <= book[person][Account.TFSA]:
        sell_tfsa(transactions, person, needs)
    else:
        sell_tfsa(transactions, person, book[person][Account.TFSA])



def invest_funds(transactions,book, parameters):
    amount_to_invest = book["joint"][Account.CLEARING]
    createTransaction(transactions, "debit", "joint", Account.CLEARING, book["joint"][Account.CLEARING],
                      TransactionType.REGULAR_ASSET_INVESTMENT)

    if parameters["spouse"]:
        amount_to_invest = amount_to_invest / 2
        createTransaction(transactions, "credit", "client", Account.REGULAR, amount_to_invest, TransactionType.REGULAR_ASSET_INVESTMENT)
        createTransaction(transactions, "credit", "spouse", Account.REGULAR, amount_to_invest,
                          TransactionType.REGULAR_ASSET_INVESTMENT)
        createTransaction(transactions, "credit", "client", Account.REGULAR_BOOK_VALUE, amount_to_invest,
                          TransactionType.REGULAR_ASSET_INVESTMENT)
        createTransaction(transactions, "credit", "spouse", Account.REGULAR_BOOK_VALUE, amount_to_invest,
                          TransactionType.REGULAR_ASSET_INVESTMENT)
    else:
        createTransaction(transactions, "credit", "client", Account.REGULAR, amount_to_invest,
                          TransactionType.REGULAR_ASSET_INVESTMENT)
        createTransaction(transactions, "credit", "client", Account.REGULAR_BOOK_VALUE, amount_to_invest,
                          TransactionType.REGULAR_ASSET_INVESTMENT)
